import Firebase from 'firebase'

// Initialize Firebase
var config = {
  
};
Firebase.initializeApp(config);
