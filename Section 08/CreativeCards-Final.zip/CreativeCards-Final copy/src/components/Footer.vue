<template>
  <footer>
    <slot name="app-name"></slot>
  </footer>
</template>

<script>
export default {
}
</script>

<style scoped>

  footer {
    margin-top: 20px;
  }

</style>
